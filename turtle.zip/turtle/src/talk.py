#!/usr/bin/env python
import rospy
from geometry_msgs.msg import Twist
from std_srvs.srv import Empty
from turtlesim.msg import Pose
def talker():
    global since
    global pose
    rospy.ServiceProxy("/reset", Empty)()
    pub = rospy.Publisher('/turtle1/cmd_vel', Twist, queue_size=10)
    rospy.Subscriber('/turtle1/pose', Pose, update_pose)
    rospy.init_node('talker', anonymous=True)
    pose = Pose()
    since = rospy.Time.now()
    twist = Twist()
    rate = rospy.Rate(10)
    while not rospy.is_shutdown():
        twist.linear.x = 1
        twist.linear.y = 0
        twist.linear.z = 0
        twist.angular.x = 0
        twist.angular.y = 0
        twist.angular.z = 1
        dur = counter()
        if dur >= rospy.Duration(3.14)and dur <= rospy.Duration(5.23):
            twist.linear.x = 2
            twist.angular.z = -3
        if dur >= rospy.Duration(5.23) and dur <= rospy.Duration(8.37):
            twist.angular.z = 1
            twist.linear.x =1
        if dur > rospy.Duration(8.37):
            twist.linear.x = 0
            twist.angular.z = 0
        pub.publish(twist)
        rate.sleep()
def counter():
    now = rospy.Time.now()
    dur = now - since
    return dur
def update_pose(data):
    pose = data
    return pose
if __name__=='__main__':
    try:
        talker()
    except rospy.ROSInterruptException:
        pass

