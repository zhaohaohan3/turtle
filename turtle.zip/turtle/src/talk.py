#!/usr/bin/env python
import rospy, time
from geometry_msgs.msg import Twist
from std_srvs.srv import Empty
since = round(time.time(), 2)
def talker():
    rospy.ServiceProxy("/reset", Empty)()
    pub = rospy.Publisher('/turtle1/cmd_vel', Twist, queue_size=10)
    rospy.init_node('talker', anonymous=True)
    twist = Twist()
    rate = rospy.Rate(100)
    while not rospy.is_shutdown():
        twist.linear.x = 1
        twist.linear.y = 0
        twist.linear.z = 0
        twist.angular.x = 0
        twist.angular.y = 0
        twist.angular.z = 1
        dur = counter()
        if dur > 4 and dur < 6.1:
            twist.linear.x = 2
            twist.angular.z = -3
        else:
            twist.linear.x = 1
            twist.angular.z = 1
        pub.publish(twist)
        rate.sleep()
def counter():
    dur = round(time.time(), 2) - since
    return dur
if __name__=='__main__':
    try:
        talker()
    except rospy.ROSInterruptException:
        pass

