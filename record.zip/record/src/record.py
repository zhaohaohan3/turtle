import rospy
import rosbag
from turtlesim.msg import Pose
bag = rosbag.Bag('dataset.bag', 'w')
def processPoseData(data):
    bag.write('Pose', data)
def main():
    rospy.init_node('record_data')
    rospy.Subscriber('/turtle1/pose', Pose, processPoseData)
    rate = rospy.Rate(10)
    while not rospy.is_shutdown():
        rate.sleep()
    else:
        bag.close()
if __name__ == '__main__':
        main()